<?php

namespace WHMCS\Module\Addon\Multipay\Admin;
use WHMCS\Database\Capsule;
/**
 * Sample Admin Area Controller
 */
class Controller {

    /**
     * Index action.
     *
     * @param array $vars Module configuration parameters
     *
     * @return string
     */
    public function index($vars)
    {
        // Get common module parameters
        $modulelink = $vars['modulelink']; // eg. addonmodules.php?module=addonmodule
        $version = $vars['version']; // eg. 1.0
        $LANG = $vars['_lang']; // an array of the currently loaded language variables

        // Get module configuration parameters
        // $configTextField = $vars['Text Field Name'];

        $limit = 10;
        $page = isset($_GET['page'])?$_GET['page']:1;
        $offset = $limit*($page-1);

        $query = Capsule::table('mod_gateway_multipay');
        $totalRecords = $query->count();
        if($page>1) $query->offset($offset);
            
        $data = $query->limit($limit)
            ->orderBy('id', 'desc')
            ->get();

        $tableBody = "";
        foreach($data as $k => $d){
            $tableBody .= "<tr>";
            $tableBody .= "<td>{$d->id}</td>";
            $tableBody .= "<td>{$d->invoiceid}</td>";
            $tableBody .= "<td>{$d->reference}</td>";
            $tableBody .= "<td>{$d->entity}</td>";
            $tableBody .= "<td>{$d->amount}</td>";
            $tableBody .= "<td>{$d->transactionid}</td>";
            $tableBody .= "<td>{$d->pay_status}</td>";
            $tableBody .= "<td>{$d->deadline}</td>";
            $tableBody .= "</tr>";
        }
        //determine the total number of pages available  
        $number_of_page = ceil ($totalRecords / $limit); 
        $prev = $page - 1;
        $next = $page + 1;

         //display the link of the pages in URL  
         $paging = '';
    // for($page = 1; $page<= $number_of_page; $page++) {  
    //     $paging .= '<a href = "'.$modulelink.'&page=' . $page . '">' . $page . ' </a>';  
    // }  

        $paging = '<nav aria-label="...">
        <ul class="pagination">';
        if($page <= 1){
            $paging .= '<li class="page-item disabled">
                <span class="page-link">Previous</span>
            </li>';
        } else {
            $paging .= '<li class="page-item">
            <a class="page-link" href="'.$modulelink.'&page='.$prev.'">Previous</a>
            </li>';
        }

        if($page < $number_of_page){
            $paging .= '<li class="page-item">
            <a class="page-link" href="'.$modulelink.'&page='.$next.'">Next</a>
            </li>';
        } else {
            $paging .= '<li class="page-item disabled">
                <span class="page-link">Next</span>
            </li>';
        }
        $paging .='</ul></nav>';

        return <<<EOF

<h2>SISLog: Payment Gateway</h2>

<p>This is payment addon module to handle custom WHMCS `mod_gateway_multipay` table.</p>

<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">#Invoice</th>
      <th scope="col">Reference</th>
      <th scope="col">Entity</th>
      <th scope="col">Amount(MZN)</th>
      <th scope="col">Transaction</th>
      <th scope="col">Status</th>
      <th scope="col">Deadline</th>
    </tr>
  </thead>
  <tbody>$tableBody<tbody>
</table>

$paging

EOF;
    }

    /**
     * Show action.
     *
     * @param array $vars Module configuration parameters
     *
     * @return string
     */
    public function show($vars)
    {
        // Get common module parameters
        $modulelink = $vars['modulelink']; // eg. addonmodules.php?module=addonmodule
        $version = $vars['version']; // eg. 1.0
        $LANG = $vars['_lang']; // an array of the currently loaded language variables

        // Get module configuration parameters
        $configTextField = $vars['Text Field Name'];
        $configPasswordField = $vars['Password Field Name'];
        $configCheckboxField = $vars['Checkbox Field Name'];
        $configDropdownField = $vars['Dropdown Field Name'];
        $configRadioField = $vars['Radio Field Name'];
        $configTextareaField = $vars['Textarea Field Name'];

        return <<<EOF

<h2>Show</h2>

<p>This is the <em>show</em> action output of the sample addon module.</p>

<p>The currently installed version is: <strong>{$version}</strong></p>

<p>
    <a href="{$modulelink}" class="btn btn-info">
        <i class="fa fa-arrow-left"></i>
        Back to home
    </a>
</p>

EOF;
    }
}
